# Bharat Electrosafe — Curated Product Image Pack

This pack contains only selected, visually strong product imagery from the supplied client archive, plus a very small `NEW_PRODUCTS` review area.

## Rules for implementation

- Use files under `WEBSITE_READY/` for the mapped product only.
- Do not rename one product's image as another product.
- `NEW_PRODUCTS/08_pvc_flooring/` contains only a **brand/reference graphic**, not a real flooring photograph.
- Files under `NEW_PRODUCTS/09_review_only_unverified/` are **NOT approved product mappings**. Do not publish them until the client confirms what they depict.
- No reliably identifiable photos were found for **Rubber Hose Pipe**, **Conveyor Belt**, or a clearly-labelled **ESD Mat** in this archive.
- For **Rubber Sheet**, there is one plausible black textured sheet candidate, but its identity is not confirmed.
- No Tata-branded imagery is included in this curated pack.

## Recommended primary card images

1. Domestic HV Insulating Mats → `domestic-hv-card.webp`
2. Auto Glow → `auto-glow-card-dark.webp`
3. Bi-Colour → `bi-colour-card-cross-section.webp`
4. Colored Strip → `colored-strip-card-installation.webp`
6. Geo Membrane Lining → `geo-membrane-card-tunnel.webp`
7. Water Stop Seal → `water-stop-card-black.webp`
8. PVC Flooring → no verified product photo found; use the brand-reference graphic only as a temporary identity/source asset, not as product photography

## New-product search result

### PVC Flooring Solutions
Found: client-supplied `bharat smart floor.pdf`, which contains Bharat Smart Floor identity artwork. No genuine flooring installation/product photograph was found.

### Rubber Sheet
No filename explicitly identifies a Rubber Sheet photo. `IMG_6036.JPG` is included under review-only because it visually resembles a black textured sheet, but this is unverified.

### Rubber Hose Pipe
No reliable product image found.

### ESD Mat
No filename explicitly identifies an ESD Mat. `IMG_6052.JPG` is included under review-only because it resembles a green textured mat/sheet, but this is unverified.

### Conveyor Belt
No reliable product image found.

For these missing products, request client photography or use the separately planned approved ImageZai category visuals; do not mislabel an insulating mat as another industrial product.

## File map

| Pack file | Source | Status | Recommended use |
|---|---|---|---|
| `WEBSITE_READY/01_domestic_hv_insulating_mats/domestic-hv-card.webp` | `IMG_6049.JPG` | VERIFIED | Best card/primary: vivid blue coined mat, clean perspective |
| `WEBSITE_READY/01_domestic_hv_insulating_mats/domestic-hv-detail.webp` | `IMG_6023.JPG` | VERIFIED | Secondary/detail: blue coined mat texture and depth |
| `WEBSITE_READY/01_domestic_hv_insulating_mats/domestic-hv-clean-product.webp` | `V4_bharatelectrosafe.com/public_html/images/electrical-insulating-mats/product-01.png` | VERIFIED | Clean product roll/render for cards or gallery |
| `WEBSITE_READY/01_domestic_hv_insulating_mats/domestic-hv-range.webp` | `Normal Mat.jpeg` | VERIFIED | Range image: multiple mat colours/surfaces |
| `WEBSITE_READY/02_auto_glow/auto-glow-card-dark.webp` | `V4_bharatelectrosafe.com/public_html/images/reflective-band-insulating/product-demo-glowing-dark.png` | VERIFIED | Best card/hero: clearly shows glowing border in low light |
| `WEBSITE_READY/02_auto_glow/auto-glow-application-dark.webp` | `V4_bharatelectrosafe.com/public_html/images/reflective-band-insulating/product-04.png` | VERIFIED | Application view in electrical room with visible glow border |
| `WEBSITE_READY/02_auto_glow/auto-glow-clean-product.webp` | `V4_bharatelectrosafe.com/public_html/images/reflective-band-insulating/product-01.png` | VERIFIED | Clean daylight product render for gallery |
| `WEBSITE_READY/03_bi_colour/bi-colour-card-cross-section.webp` | `V4_bharatelectrosafe.com/public_html/images/bi-color-insulating-mats/product-02.png` | VERIFIED | Best card: complete mat plus magnified second-colour layer |
| `WEBSITE_READY/03_bi_colour/bi-colour-layer-detail.webp` | `V4_bharatelectrosafe.com/public_html/images/bi-color-insulating-mats/product-03.png` | VERIFIED | Technical layer detail |
| `WEBSITE_READY/03_bi_colour/bi-colour-clean-product.webp` | `V4_bharatelectrosafe.com/public_html/images/bi-color-insulating-mats/product-01.png` | VERIFIED | Clean product view |
| `WEBSITE_READY/04_colored_strip/colored-strip-card-installation.webp` | `V4_bharatelectrosafe.com/public_html/images/coloured-strip-insulating/product-01.png` | VERIFIED | Best card: installed in front of electrical control equipment |
| `WEBSITE_READY/04_colored_strip/colored-strip-production.webp` | `V4_bharatelectrosafe.com/public_html/images/coloured-strip-insulating/product-03.png` | VERIFIED | Strong manufacturing/production visual |
| `WEBSITE_READY/04_colored_strip/colored-strip-clean-product.webp` | `V4_bharatelectrosafe.com/public_html/images/coloured-strip-insulating/product-02.png` | VERIFIED | Clean product render |
| `WEBSITE_READY/05_international_iec_61111/iec-marking-class-2.webp` | `IEC 61111 Class 2.jpeg` | VERIFIED | IEC Class 2 product marking |
| `WEBSITE_READY/05_international_iec_61111/iec-marking-range.webp` | `IEC 61111.jpeg` | VERIFIED | IEC marking/product identification |
| `WEBSITE_READY/05_international_iec_61111/iec-marking-class-0-2-2mm.webp` | `IEC 61111 Class 0-2 (2MM).jpeg` | VERIFIED | IEC Class 0–2 / 2 mm marking reference |
| `WEBSITE_READY/06_geo_membrane/geo-membrane-card-tunnel.webp` | `V4_bharatelectrosafe.com/public_html/images/membrane/product-01.png` | VERIFIED | Best card: real tunnel waterproofing application |
| `WEBSITE_READY/06_geo_membrane/geo-membrane-installation-worker.webp` | `V4_bharatelectrosafe.com/public_html/images/membrane/product-02.png` | VERIFIED | Worker installing/welding membrane |
| `WEBSITE_READY/06_geo_membrane/geo-membrane-large-scale.webp` | `V4_bharatelectrosafe.com/public_html/images/membrane/product-05.png` | VERIFIED | Large-scale containment/lining application |
| `WEBSITE_READY/07_water_stop_seal/water-stop-card-black.webp` | `Water Stop Seal1.png` | VERIFIED | Best card: clean black engineered profile |
| `WEBSITE_READY/07_water_stop_seal/water-stop-black-alternate.webp` | `Water Stop Seal6.png` | VERIFIED | Alternate black profile |
| `WEBSITE_READY/07_water_stop_seal/water-stop-light-profile.webp` | `Water Stop Seal7.png` | VERIFIED | Light-colour profile variant |
| `NEW_PRODUCTS/08_pvc_flooring/pvc-flooring-brand-reference-only.webp` | `bharat smart floor.pdf — rendered page 1` | REFERENCE_ONLY | Brand/reference artwork only; NOT a real product/application photo |
| `NEW_PRODUCTS/09_review_only_unverified/possible-rubber-sheet-IMG_6036_DO_NOT_PUBLISH.webp` | `IMG_6036.JPG` | UNVERIFIED_DO_NOT_PUBLISH | Looks like a black textured rubber/sheet material, but archive does not identify it as Rubber Sheet. |
| `NEW_PRODUCTS/09_review_only_unverified/possible-esd-mat-IMG_6052_DO_NOT_PUBLISH.webp` | `IMG_6052.JPG` | UNVERIFIED_DO_NOT_PUBLISH | Looks like a green textured sheet/mat, but archive does not identify it as an ESD Mat. |

---

## Original About-page assets added in v2

See `ABOUT_SITE_SELECTED/README_ABOUT_SITE_ASSETS.md`.

The v2 pack adds the best useful original-site assets:
- all three original leadership portraits,
- Core Values image,
- INSULATICAA brand asset,
- current approved transparent Bharat Electrosafe ® logo,
- two legacy composition graphics marked REFERENCE ONLY.

The old original-site Bharat Electrosafe TM logo is intentionally excluded.


---

## v3 additions from the original public website
See `ORIGINAL_SITE_SELECTED/README_ORIGINAL_SITE_SELECTION.md`.
Added: original-site product alternates, yellow-strip variant, manufacturing/application photos, awards, client logos, and certificate icons. Excluded: TATA-branded assets and obsolete TM brand art.
