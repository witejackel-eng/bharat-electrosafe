# Bharat Electrosafe original-site image additions (v3)

Source reviewed: the client's original website at https://bharatelectrosafe.com/index.php and related pages.

## What was added

### 1) PRODUCT_ALTERNATES_WEBSITE_READY
Original public-site product renders that are visually clean and useful as alternate product cards or supporting imagery:
- Domestic HV brown mat render
- Coloured Strip blue/yellow mat render
- Bi-Colour blue/red mat render
- Auto Glow green-edge mat render

### 2) NEW_PRODUCTS_AND_VARIANTS_WEBSITE_READY
- Yellow Strip installed switchgear-room image

This is useful because it shows an additional product/variant not emphasized in the earlier curated pack.

### 3) FACILITY_AND_APPLICATION_IMAGES_WEBSITE_READY
- Manufacturing setup factory photo
- Installed corridor blue-mat application photo

These are strong trust-building visuals for home/about pages.

### 4) TRUST_AND_SOCIAL_PROOF_WEBSITE_READY
- 2 awards images
- 8 client logos
- 12 certificate/membership icons

Useful for awards, organisations represented, and certification carousels.

## Reference-only files
- Unique Attributes graphic
- Dual-layer explanatory graphic

These contain baked-in old text/design treatment and should be used only as reference, not as direct publish-ready hero assets.

## Important exclusions
Do NOT use the following from the original site:
- any TATA-branded artwork (`about-us.png`, `marketed-by-tata.*`, related legacy compositions)
- old Bharat Electrosafe TM brand mark (`brand-bharat-electrosafe.png`)

Continue using the current approved transparent ® logo already included in:
`ABOUT_SITE_SELECTED/CURRENT_APPROVED_BRAND/`

## Practical recommendation for Z.ai
For actual website implementation, prioritize the earlier curated product shots in `WEBSITE_READY/` first, then use these original-site additions as supporting alternates, social proof, and category-variant imagery.
