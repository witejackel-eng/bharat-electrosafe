# Original Bharat Electrosafe About-page asset selection

Source reviewed: https://bharatelectrosafe.com/about-us.php

## WEBSITE_READY

These are genuine assets used on the original public About page and are suitable
for consideration in the redesigned website:

- `leadership-vishnu-gupta-original-site.png`
- `leadership-krishan-kumar-original-site.png`
- `leadership-priyanka-garg-original-site.png`
- `core-values-original-site.png`
- `insulaticaa-brand-original-site.png`

### Recommended use

- Leadership portraits: leadership flip-card fronts.
- Core Values image: optional supporting visual in the Values / Why Bharat
  Electrosafe area. Keep it in a controlled editorial frame; do not make it a
  giant full-width image.
- INSULATICAA: BES Brands section, preferably on a surface with sufficient
  contrast.

## CURRENT_APPROVED_BRAND

Use the current transparent Bharat Electrosafe ® artwork from this folder for
header/footer/BES Brands. It replaces the obsolete company-logo artwork from
the original site.

## REFERENCE_ONLY_DO_NOT_PUBLISH

- `who-we-are-legacy-composition-REFERENCE_ONLY.png`
- `why-choose-us-legacy-composition-REFERENCE_ONLY.png`

These are useful only as composition/story references. They contain embedded
legacy Bharat Electrosafe branding and should NOT be published directly in the
new site. Reuse the design idea only if useful, with current approved assets.

## Explicit exclusion

The original site's `brand-bharat-electrosafe.png` was reviewed but deliberately
NOT included because it contains the obsolete **TM** mark. Never replace the
current ® logo with that file.

## General rule

Do not bulk-import this pack into `/public`. Copy only individually approved
assets, optimize for the actual display size, preserve truthful alt text, and
avoid duplicating images already present in the repository.
