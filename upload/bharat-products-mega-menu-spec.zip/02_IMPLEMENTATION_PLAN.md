# Implementation Plan Against Current Code

Relevant current files:
- `src/components/layout/Header.tsx`
- `src/data/product-navigation.ts`

## 1. Width
Current panel uses `w-[900px]`.
Replace with roughly:
```tsx
w-[820px] xl:w-[840px] max-w-[calc(100vw-32px)]
```

## 2. Fix the structural height bug
Current body uses a shared two-row grid. The tall Electrical block controls the first row height and pushes PVC/Other down.

Do NOT use a row-coupled 2×2 grid. Use two independent vertical stacks:
```tsx
<div className="grid grid-cols-[1.18fr_0.82fr] gap-x-7">
  <div className="flex flex-col min-w-0">
    <ElectricalGroup />
    <PVCGroup className="mt-4" />
  </div>
  <div className="flex flex-col min-w-0">
    <WaterproofingGroup />
    <BlueprintIllustration className="my-2" />
    <OtherProductsGroup />
  </div>
</div>
```

## 3. Compact Electrical
Render Domestic and International side-by-side:
```tsx
<div className="grid grid-cols-2 gap-x-5">
  <SubGroup subgroup={domesticSub} />
  <SubGroup subgroup={internationalSub} />
</div>
```
This is mandatory.

## 4. Illustration
Remove the current full-panel faint SVG.
Copy `04_products-blueprint.svg` to `public/brand/products-menu-blueprint.svg`.
Render it in a dedicated right-column slot:
```tsx
<div className="h-[86px] flex items-center justify-center" aria-hidden="true">
  <img src="/brand/products-menu-blueprint.svg" alt=""
       className="w-[182px] h-auto opacity-[0.21] pointer-events-none select-none" />
</div>
```

## 5. Tighten spacing
- panel content: `px-5 py-4`
- eyebrow bottom margin: 10–12px
- group title bottom: 6–8px
- leaf line box: 22–24px
- Electrical → PVC: 16–20px
- Waterproofing → illustration: 8–10px
- illustration → Other: 8–10px
- body → utility row: 10–12px

## 6. Keep central data
Continue consuming the current central product navigation data. Do not create a duplicate product catalogue inside Header.

## 7. Keep mobile
The current mobile accordion hierarchy is already the right architecture. Preserve it and only fix regressions if any.
