# Final Menu Spec

## Geometry
- >=1440px: 840px wide, 330–360px tall
- 1280–1439px: 820px wide
- lower desktop: min(780px, calc(100vw - 32px))
- padding: 16px vertical / 20px horizontal
- radius: 14–16px

## Exact spatial shape
```text
┌──────────────────────────────────────────────────────────────┐
│ PRODUCTS                                                     │
│                                                              │
│ 01 ELECTRICAL INSULATING MATS     02 WATER PROOFING          │
│                                                              │
│ Domestic · IS 15652:2006          Geo Membrane Lining       │
│ HV Insulating Mats                Water Stop Seal            │
│ Auto Glow                                                    │
│ Bi-Colour                         [ABSTRACT ILLUSTRATION]     │
│ Colored Strip                                                │
│                                                              │
│ International / Global                                      │
│ · IEC 61111:2009                                            │
│ HV Insulating Mats                                          │
│ Auto Glow                         04 OTHER PRODUCTS          │
│ Bi-Colour                         Rubber Sheet               │
│                                   Rubber Hose Pipe           │
│ 03 PVC FLOORING SOLUTIONS         ESD Mat                    │
│ PVC Flooring Solutions            Conveyor Belt              │
│                                                              │
├──────────────────────────────────────────────────────────────┤
│ Technical Guidance →                 View All Products →     │
└──────────────────────────────────────────────────────────────┘
```

## Required compaction
Inside Electrical, render Domestic and International side-by-side on desktop:
```text
Domestic · IS 15652:2006       International / Global · IEC 61111:2009
HV Insulating Mats             HV Insulating Mats
Auto Glow                      Auto Glow
Bi-Colour                      Bi-Colour
Colored Strip
```

## Illustration
Use `04_products-blueprint.svg` in its own dedicated slot between Waterproofing and Other Products.
- 175–190px wide
- 82–92px slot
- opacity 0.18–0.24
- centered
- not behind text
- aria-hidden, pointer-events none
- no animation

## Typography
- eyebrow 10px
- group title 13px bold uppercase
- number 11px gold
- subrange 12px semibold
- standard marker 9px
- leaf links 13px, 22–24px line box

Do not change header height, logo, nav, routes, product content, hero, or footer.
