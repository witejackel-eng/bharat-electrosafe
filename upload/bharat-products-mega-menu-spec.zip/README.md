# Bharat Electrosafe — Products Mega-Menu Final Spec

This bundle is the authoritative handoff for the final Products mega-menu. It defines exact geometry, hierarchy, a visible abstract illustration, implementation rules, and QA.

## Current defects
1. The current menu is too large because the 900px panel uses a shared 2-row grid; the tall Electrical block pushes the lower row down and creates a large empty middle area.
2. The current full-panel SVG illustration is effectively invisible because its strokes are spread across the whole panel at very low opacity.

## Final design
- Desktop width: 820px at 1280–1439; 840px at >=1440.
- Target height at 1440: 330–360px.
- No product photograph.
- Left stack: Electrical Insulating Mats → PVC Flooring Solutions.
- Right stack: Waterproofing Solutions → visible abstract illustration → Other Products.
- Domestic + International sit side-by-side inside Electrical on desktop.
- Technical Guidance stays bottom-left; View All Products stays bottom-right.
- Mobile keeps the accordion hierarchy.
