# Acceptance Checklist

## Desktop 1440
- [ ] width 832–848px
- [ ] total height <=360px
- [ ] no internal scrolling
- [ ] no product photo
- [ ] abstract illustration clearly visible
- [ ] Electrical top-left
- [ ] Waterproofing top-right
- [ ] PVC lower-left
- [ ] Other lower-right
- [ ] Domestic + International clearly inside Electrical
- [ ] every child link visible
- [ ] View All Products visible without scrolling
- [ ] Technical Guidance visible without scrolling

## Interaction
- [ ] hover opens
- [ ] trigger click works
- [ ] ArrowDown works
- [ ] Escape closes and restores trigger focus
- [ ] outside click closes
- [ ] links close menu and navigate

## Mobile
- [ ] existing accordion preserved
- [ ] same hierarchy
- [ ] all leaf routes reachable

## Regression
- [ ] header height unchanged
- [ ] logo unchanged
- [ ] nav unchanged
- [ ] hero unchanged
- [ ] footer unchanged

## Verification
- [ ] npm run typecheck
- [ ] npm run lint
- [ ] npm test
- [ ] npm run build
- [ ] relevant Playwright/navigation tests
