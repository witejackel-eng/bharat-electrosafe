# Tailwind Reference

Panel:
```tsx
absolute left-1/2 -translate-x-1/2 top-full mt-1.5
w-[820px] xl:w-[840px] max-w-[calc(100vw-32px)]
bg-be-white border border-be-grey-250/80 rounded-2xl
shadow-[0_10px_30px_rgba(0,0,0,0.09),0_2px_6px_rgba(0,0,0,0.05)]
overflow-hidden
```

Content: `px-5 py-4`

Two independent columns: `grid grid-cols-[1.18fr_0.82fr] gap-x-7`

Electrical subgrid: `grid grid-cols-2 gap-x-5`

Illustration:
```tsx
<div className="h-[86px] flex items-center justify-center" aria-hidden="true">
  <img src="/brand/products-menu-blueprint.svg" alt=""
       className="w-[182px] h-auto opacity-[0.21] pointer-events-none select-none" />
</div>
```

Leaf: `text-[13px] leading-[22px] font-medium ... px-1.5 py-[3px]`

Important: do not use a shared 2-row category grid.
